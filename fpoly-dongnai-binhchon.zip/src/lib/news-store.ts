import { asc, desc, sql } from "drizzle-orm";
import { db, newsArticles, pool } from "@/db";
import { CAMPUS_NEWS, type NewsArticle } from "@/data/contest-content";

let initializedPromise: Promise<void> | null = null;

/**
 * Safely creates `news_articles` table if it doesn't exist yet and seeds initial
 * FPoly Đồng Nai news stories ONLY when the table is completely empty.
 * Never modifies `candidates`, `users`, or `votes`.
 */
export async function ensureNewsArticlesTable(): Promise<void> {
  if (!initializedPromise) {
    initializedPromise = (async () => {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS news_articles (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          category VARCHAR(100) NOT NULL,
          campus VARCHAR(120) NOT NULL,
          title TEXT NOT NULL,
          excerpt TEXT NOT NULL,
          content JSONB NOT NULL DEFAULT '[]'::jsonb,
          published_at VARCHAR(50) NOT NULL,
          read_time VARCHAR(50) NOT NULL,
          image_url TEXT NOT NULL,
          featured BOOLEAN NOT NULL DEFAULT FALSE,
          sort_order INTEGER NOT NULL DEFAULT 0,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );
      `);

      const [{ count }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(newsArticles);

      if (count === 0) {
        await db.insert(newsArticles).values(
          CAMPUS_NEWS.map((item, idx) => ({
            category: item.category,
            campus: item.campus,
            title: item.title,
            excerpt: item.excerpt,
            content: item.content,
            publishedAt: item.publishedAt,
            readTime: item.readTime,
            imageUrl: item.imageUrl,
            featured: Boolean(item.featured),
            sortOrder: idx + 1,
          }))
        );
      }
    })().catch((err) => {
      initializedPromise = null;
      throw err;
    });
  }

  return initializedPromise;
}

export async function getAllNewsArticles(): Promise<NewsArticle[]> {
  try {
    await ensureNewsArticlesTable();
    const rows = await db
      .select()
      .from(newsArticles)
      .orderBy(
        desc(newsArticles.featured),
        asc(newsArticles.sortOrder),
        desc(newsArticles.createdAt)
      );

    return rows.map((row) => ({
      id: row.id,
      category: row.category,
      campus: row.campus,
      title: row.title,
      excerpt: row.excerpt,
      content: Array.isArray(row.content) ? row.content : [],
      publishedAt: row.publishedAt,
      readTime: row.readTime,
      imageUrl: row.imageUrl,
      featured: row.featured,
    }));
  } catch (error) {
    console.error("Fallback to static CAMPUS_NEWS:", error);
    return CAMPUS_NEWS;
  }
}
