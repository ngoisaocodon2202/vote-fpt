import { NextResponse } from "next/server";
import { connection } from "next/server";
import { db, candidates } from "@/db";
import { desc, asc } from "drizzle-orm";

export async function GET() {
  await connection();

  try {
    const rows = await db
      .select()
      .from(candidates)
      .orderBy(desc(candidates.voteCount), asc(candidates.studentId));

    const totalVotes = rows.reduce((sum, c) => sum + (c.voteCount || 0), 0);

    const ranked = rows.map((candidate, index) => ({
      ...candidate,
      rank: index + 1,
    }));

    return NextResponse.json(
      {
        candidates: ranked,
        totalVotes,
        updatedAt: new Date().toISOString(),
      },
      {
        headers: {
          "Cache-Control": "no-store, max-age=0",
        },
      }
    );
  } catch (error) {
    console.error("Failed to fetch candidates:", error);
    return NextResponse.json(
      { error: "Không thể tải danh sách thí sinh." },
      { status: 500 }
    );
  }
}
