import { NextResponse } from "next/server";
import { connection } from "next/server";
import { getAllNewsArticles } from "@/lib/news-store";

export async function GET() {
  await connection();
  const articles = await getAllNewsArticles();
  return NextResponse.json(
    { articles, updatedAt: new Date().toISOString() },
    {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    }
  );
}
