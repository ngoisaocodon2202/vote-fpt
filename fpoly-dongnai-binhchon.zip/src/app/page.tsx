import { Suspense } from "react";
import Image from "next/image";
import { connection } from "next/server";
import { desc, asc } from "drizzle-orm";
import { db, candidates } from "@/db";
import { getAllNewsArticles } from "@/lib/news-store";
import { VotingLandingClient } from "@/components/VotingLandingClient";
import type { RankedCandidate } from "@/types/voting";
import type { NewsArticle } from "@/data/contest-content";

async function DynamicVotingContent() {
  await connection();

  let initialCandidates: RankedCandidate[] = [];
  let initialTotalVotes = 0;
  let initialNews: NewsArticle[] = [];

  try {
    const [rows, articles] = await Promise.all([
      db
        .select()
        .from(candidates)
        .orderBy(desc(candidates.voteCount), asc(candidates.studentId)),
      getAllNewsArticles(),
    ]);

    initialTotalVotes = rows.reduce((sum, item) => sum + item.voteCount, 0);
    initialCandidates = rows.map((row, idx) => ({
      ...row,
      createdAt: row.createdAt ? row.createdAt.toISOString() : null,
      rank: idx + 1,
    }));
    initialNews = articles;
  } catch (error) {
    console.error("Initial DB fetch warning:", error);
  }

  return (
    <VotingLandingClient
      initialCandidates={initialCandidates}
      initialTotalVotes={initialTotalVotes}
      initialNews={initialNews}
    />
  );
}

function LandingShellFallback() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white px-4 text-center">
      <Image
        src="/images/fpt-logo.png"
        alt="Logo FPT Polytechnic Đồng Nai"
        width={136}
        height={83}
        priority
        className="mb-5 h-12 w-auto object-contain animate-pulse"
      />
      <p className="text-xs sm:text-sm font-bold tracking-wider text-[#F26F21] uppercase whitespace-nowrap">
        Đang tải Cổng Bình Chọn FPT Polytechnic Đồng Nai...
      </p>
    </div>
  );
}

export default function HomePage() {
  return (
    <Suspense fallback={<LandingShellFallback />}>
      <DynamicVotingContent />
    </Suspense>
  );
}
