import "dotenv/config";
import { notInArray, sql } from "drizzle-orm";
import { db, pool, candidates, newsArticles } from "./index";
import { CAMPUS_NEWS } from "../data/contest-content";

const initialCandidates = [
  {
    fullName: "Nguyễn Minh Khôi",
    dob: "2005-05-18",
    studentId: "PS38102",
    major: "Phát triển Phần mềm",
    avatarUrl: "/images/candidates/candidate-1.jpg",
    bio: "“Thực học — Thực nghiệp: Công nghệ chỉ thực sự ý nghĩa khi giải quyết bài toán thực tế.” — Quán quân FPoly Hackathon khu vực phía Nam, trưởng nhóm dự án phần mềm chuyển đổi số cho doanh nghiệp trẻ tại Biên Hòa — Đồng Nai.",
    voteCount: 1482,
  },
  {
    fullName: "Trần Bảo Ngọc",
    dob: "2005-09-12",
    studentId: "PS38415",
    major: "Thiết kế Đồ họa",
    avatarUrl: "/images/candidates/candidate-2.jpg",
    bio: "“Mỗi nét vẽ số là một nhịp cầu đưa văn hóa địa phương đến gần giới trẻ.” — Giải Nhất Sáng tạo Mỹ thuật Số FPoly 2026 với dự án nhận diện Gốm Biên Hòa Đương Đại, Chủ nhiệm CLB Thiết kế Trẻ FPT Polytechnic Đồng Nai.",
    voteCount: 1439,
  },
  {
    fullName: "Lê Hoàng Nam",
    dob: "2005-11-03",
    studentId: "PS38079",
    major: "Lập trình Web",
    avatarUrl: "/images/candidates/candidate-3.jpg",
    bio: "“Viết code chuẩn chỉnh, xây sản phẩm bền vững từ ghế giảng đường.” — Danh hiệu Ong Vàng xuất sắc 4 học kỳ liên tiếp tại FPT Polytechnic Đồng Nai, tác giả nền tảng kết nối thực tập sinh doanh nghiệp Đồng Nai.",
    voteCount: 1365,
  },
  {
    fullName: "Phạm Khánh Linh",
    dob: "2005-02-24",
    studentId: "PS39108",
    major: "PR & Tổ chức Sự kiện",
    avatarUrl: "/images/candidates/candidate-4.jpg",
    bio: "“Kể chuyện tử tế để lan tỏa năng lượng tích cực mỗi ngày.” — Én Vàng MC Học đường FPT Polytechnic Đồng Nai, trưởng ban điều phối chuỗi sự kiện chào tân sinh viên thu hút hơn 3.000 người tham dự.",
    voteCount: 1194,
  },
  {
    fullName: "Võ Quốc Thịnh",
    dob: "2005-07-30",
    studentId: "PS38890",
    major: "Thiết kế UI/UX & Đa phương tiện",
    avatarUrl: "/images/candidates/candidate-5.jpg",
    bio: "“Biến từng giờ xưởng thực hành thành sản phẩm thương mại thực thụ.” — Gương mặt tiêu biểu Xưởng dự án FPoly Đồng Nai, thiết kế giao diện ứng dụng cho 10 dự án khởi nghiệp sinh viên và doanh nghiệp địa phương.",
    voteCount: 1088,
  },
  {
    fullName: "Đặng Phương Anh",
    dob: "2005-12-09",
    studentId: "PS39421",
    major: "Quản trị Kinh doanh & Logistics",
    avatarUrl: "/images/candidates/candidate-6.jpg",
    bio: "“Bản lĩnh sinh viên thực chiến bắt đầu từ khát vọng nâng tầm nông sản quê hương.” — Giải Nhất Poly Startup 2026 cơ sở Đồng Nai với dự án chuỗi cung ứng đặc sản trái cây Long Khánh — Đồng Nai.",
    voteCount: 976,
  },
  {
    fullName: "Hoàng Gia Huy",
    dob: "2006-03-15",
    studentId: "PS39156",
    major: "Ứng dụng Phần mềm & AI",
    avatarUrl: "/images/candidates/candidate-7.jpg",
    bio: "“Đam mê lập trình AI, sống trọn âm nhạc và cháy hết mình cùng phong trào.” — Tác giả trợ lý AI tra cứu lịch học & quy chế thi cho sinh viên FPoly Đồng Nai kiêm Chủ nhiệm CLB Âm nhạc cơ sở.",
    voteCount: 892,
  },
  {
    fullName: "Bùi Thanh Thảo",
    dob: "2005-08-21",
    studentId: "PS38219",
    major: "Digital Marketing",
    avatarUrl: "/images/candidates/candidate-8.jpg",
    bio: "“Sáng tạo có chiến lược, chạm cảm xúc bằng sự chân thành.” — Trưởng nhóm dự án truyền thông số đạt hơn 2 triệu lượt tiếp cận tự nhiên, thủ lĩnh chiến dịch thiện nguyện 'Áo Cam Đồng Nai Sẻ Chia'.",
    voteCount: 845,
  },
];

async function main() {
  console.log(
    "🚀 Initializing FPT Polytechnic Đồng Nai Voting PostgreSQL schema & seed data..."
  );

  await db.execute(sql`CREATE EXTENSION IF NOT EXISTS "pgcrypto";`);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email VARCHAR(255) UNIQUE NOT NULL,
      name VARCHAR(255),
      avatar_url TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS candidates (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      full_name VARCHAR(255) NOT NULL,
      dob DATE NOT NULL,
      student_id VARCHAR(50) UNIQUE NOT NULL,
      major VARCHAR(150) NOT NULL,
      avatar_url TEXT NOT NULL,
      bio TEXT,
      vote_count INT DEFAULT 0,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS votes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID REFERENCES users(id) ON DELETE CASCADE,
      candidate_id UUID REFERENCES candidates(id) ON DELETE CASCADE,
      voted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      vote_date DATE DEFAULT CURRENT_DATE
    );
  `);

  await db.execute(sql`
    CREATE INDEX IF NOT EXISTS idx_user_daily_votes ON votes(user_id, vote_date);
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS news_articles (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      category VARCHAR(100) NOT NULL,
      campus VARCHAR(120) NOT NULL,
      title TEXT NOT NULL,
      excerpt TEXT NOT NULL,
      content JSONB NOT NULL DEFAULT '[]'::jsonb,
      published_at VARCHAR(50) NOT NULL,
      read_time VARCHAR(50) NOT NULL,
      image_url TEXT NOT NULL,
      featured BOOLEAN NOT NULL DEFAULT FALSE,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);

  const activeIds = initialCandidates.map((c) => c.studentId);
  await db
    .delete(candidates)
    .where(notInArray(candidates.studentId, activeIds));

  for (const item of initialCandidates) {
    await db
      .insert(candidates)
      .values(item)
      .onConflictDoUpdate({
        target: candidates.studentId,
        set: {
          fullName: item.fullName,
          dob: item.dob,
          major: item.major,
          avatarUrl: item.avatarUrl,
          bio: item.bio,
          voteCount: item.voteCount,
        },
      });
  }

  const [{ newsCount }] = await db
    .select({ newsCount: sql<number>`count(*)::int` })
    .from(newsArticles);

  if (newsCount === 0) {
    await db.insert(newsArticles).values(
      CAMPUS_NEWS.map((item, idx) => ({
        category: item.category,
        campus: item.campus,
        title: item.title,
        excerpt: item.excerpt,
        content: item.content,
        publishedAt: item.publishedAt,
        readTime: item.readTime,
        imageUrl: item.imageUrl,
        featured: Boolean(item.featured),
        sortOrder: idx + 1,
      }))
    );
  }

  console.log(
    `✅ Successfully seeded ${initialCandidates.length} candidates & news articles for FPT Polytechnic Đồng Nai!`
  );
  await pool.end();
}

main().catch(async (err) => {
  console.error("❌ Seed error:", err);
  await pool.end();
  process.exit(1);
});
