"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { useSession } from "next-auth/react";
import type {
  CandidatesApiResponse,
  LiveVoteFeedItem,
  RankedCandidate,
  VoteStatusResponse,
} from "@/types/voting";
import type { VoteBroadcastPayload } from "@/lib/broadcaster";
import { fireFptVoteConfetti } from "@/components/motion/MotionPrimitives";

const fetcher = async <T,>(url: string): Promise<T> => {
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`API error: ${res.status}`);
  }
  return res.json();
};

function sortAndRank(list: RankedCandidate[]): RankedCandidate[] {
  return [...list]
    .sort((a, b) => {
      if (b.voteCount !== a.voteCount) return b.voteCount - a.voteCount;
      return a.studentId.localeCompare(b.studentId);
    })
    .map((item, idx) => ({
      ...item,
      rank: idx + 1,
    }));
}

interface UseRealtimeVotingOptions {
  initialCandidates: RankedCandidate[];
  initialTotalVotes: number;
}

export function useRealtimeVoting({
  initialCandidates,
  initialTotalVotes,
}: UseRealtimeVotingOptions) {
  const { data: session, status: sessionStatus } = useSession();

  const [sseConnected, setSseConnected] = useState(false);
  const [votingCandidateId, setVotingCandidateId] = useState<string | null>(
    null
  );
  const [liveFeed, setLiveFeed] = useState<LiveVoteFeedItem[]>([]);
  const [toastMessage, setToastMessage] = useState<{
    id: string;
    title: string;
    subtitle: string;
    tone: "success" | "warning" | "live";
  } | null>(null);
  const [authModalCandidate, setAuthModalCandidate] =
    useState<RankedCandidate | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const fallbackData = useMemo<CandidatesApiResponse>(
    () => ({
      candidates: sortAndRank(initialCandidates),
      totalVotes: initialTotalVotes,
      updatedAt: "",
    }),
    [initialCandidates, initialTotalVotes]
  );

  const {
    data: candidatesData,
    mutate: mutateCandidates,
  } = useSWR<CandidatesApiResponse>("/api/candidates", fetcher, {
    fallbackData,
    refreshInterval: 10000,
    revalidateOnFocus: true,
    dedupingInterval: 1500,
  });

  const {
    data: voteStatus,
    mutate: mutateVoteStatus,
  } = useSWR<VoteStatusResponse>("/api/votes/status", fetcher, {
    revalidateOnFocus: true,
    refreshInterval: 30000,
  });

  // Re-fetch user quota whenever NextAuth session status changes
  useEffect(() => {
    if (sessionStatus !== "loading") {
      mutateVoteStatus();
    }
  }, [sessionStatus, session?.user?.email, mutateVoteStatus]);

  const showToast = useCallback(
    (
      title: string,
      subtitle: string,
      tone: "success" | "warning" | "live" = "success"
    ) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setToastMessage({ id, title, subtitle, tone });
    },
    []
  );

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage((prev) => (prev?.id === toastMessage.id ? null : prev));
    }, 4200);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // Connect to Server-Sent Events (SSE) for instant zero-latency leaderboard updates
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      eventSource = new EventSource("/api/stream");

      eventSource.onopen = () => {
        setSseConnected(true);
      };

      eventSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data) as
            | { type: "CONNECTED"; timestamp: string }
            | VoteBroadcastPayload;

          if (payload.type === "CONNECTED") {
            setSseConnected(true);
            return;
          }

          if (payload.type === "VOTE_CAST") {
            mutateCandidates((current) => {
              const base = current ?? fallbackData;
              const updatedList = base.candidates.map((c) =>
                c.id === payload.candidateId
                  ? {
                      ...c,
                      voteCount: Math.max(c.voteCount, payload.newVoteCount),
                    }
                  : c
              );
              const ranked = sortAndRank(updatedList);
              const computedTotal = ranked.reduce(
                (acc, item) => acc + item.voteCount,
                0
              );
              return {
                candidates: ranked,
                totalVotes: Math.max(computedTotal, payload.totalVotes),
                updatedAt: payload.timestamp,
              };
            }, false);

            const feedItem: LiveVoteFeedItem = {
              id: `${payload.timestamp}-${payload.candidateId}`,
              candidateId: payload.candidateId,
              candidateName: payload.candidateName,
              studentId: payload.studentId,
              newVoteCount: payload.newVoteCount,
              voterHint: payload.voterHint,
              timestamp: payload.timestamp,
            };

            setLiveFeed((prev) => [feedItem, ...prev].slice(0, 6));
          }
        } catch {
          // Ignore malformed event
        }
      };

      eventSource.onerror = () => {
        setSseConnected(false);
        eventSource?.close();
        reconnectTimer = setTimeout(connect, 3500);
      };
    };

    connect();

    return () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      eventSource?.close();
    };
  }, [fallbackData, mutateCandidates]);

  const openSignInPrompt = useCallback((candidate?: RankedCandidate | null) => {
    setAuthModalCandidate(candidate ?? null);
    setIsAuthModalOpen(true);
  }, []);

  const closeSignInPrompt = useCallback(() => {
    setIsAuthModalOpen(false);
    setAuthModalCandidate(null);
  }, []);

  const handleMidnightReset = useCallback(() => {
    mutateVoteStatus();
    mutateCandidates();
    showToast(
      "Đã làm mới lượt bình chọn ngày mới!",
      "Bạn vừa nhận lại 03 lượt bình chọn mới hôm nay.",
      "success"
    );
  }, [mutateCandidates, mutateVoteStatus, showToast]);

  const castVote = useCallback(
    async (
      candidate: RankedCandidate,
      originRect?: DOMRect | null
    ): Promise<boolean> => {
      const isAuthenticated =
        sessionStatus === "authenticated" || Boolean(voteStatus?.authenticated);

      if (!isAuthenticated) {
        openSignInPrompt(candidate);
        return false;
      }

      const remaining = voteStatus?.remainingVotes ?? 3;
      if (remaining <= 0) {
        showToast(
          "Đã hết 03 lượt bình chọn hôm nay",
          "Vui lòng chờ đồng hồ đếm ngược về 00:00:00 để tiếp tục bình chọn.",
          "warning"
        );
        return false;
      }

      if (votingCandidateId) return false;
      setVotingCandidateId(candidate.id);

      try {
        const res = await fetch("/api/vote", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ candidateId: candidate.id }),
        });

        const data = await res.json();

        if (res.status === 401) {
          openSignInPrompt(candidate);
          return false;
        }

        if (res.status === 429 || data.code === "DAILY_LIMIT_REACHED") {
          await mutateVoteStatus();
          showToast(
            "Đã chạm giới hạn 03 lượt/ngày",
            "Hệ thống sẽ mở lại 03 lượt mới vào đúng 00:00:00 đêm nay.",
            "warning"
          );
          return false;
        }

        if (!res.ok) {
          showToast(
            "Không thể ghi nhận bình chọn",
            data.error || "Vui lòng thử lại sau giây lát.",
            "warning"
          );
          return false;
        }

        // Fire FPT confetti burst from button position!
        fireFptVoteConfetti(originRect);

        // Immediately sync candidate leaderboard & user daily quota
        mutateCandidates((current) => {
          const base = current ?? fallbackData;
          const updated = base.candidates.map((c) =>
            c.id === candidate.id
              ? { ...c, voteCount: data.newVoteCount ?? c.voteCount + 1 }
              : c
          );
          const ranked = sortAndRank(updated);
          return {
            candidates: ranked,
            totalVotes:
              data.totalVotes ??
              ranked.reduce((sum, item) => sum + item.voteCount, 0),
            updatedAt: new Date().toISOString(),
          };
        }, false);

        mutateVoteStatus(
          (prev) =>
            prev
              ? {
                  ...prev,
                  votesUsedToday: data.votesUsedToday,
                  remainingVotes: data.remainingVotes,
                  votedCandidateIdsToday: data.votedCandidateIdsToday,
                  nextResetAt: data.nextResetAt || prev.nextResetAt,
                }
              : prev,
          false
        );

        const leftText =
          data.remainingVotes > 0
            ? `Bạn còn ${data.remainingVotes}/3 lượt bình chọn hôm nay.`
            : "Bạn đã hoàn thành 3/3 lượt bình chọn hôm nay!";

        showToast(
          `Đã bình chọn cho ${candidate.fullName}!`,
          leftText,
          "success"
        );

        return true;
      } catch {
        showToast(
          "Lỗi kết nối mạng",
          "Không thể gửi phiếu bầu lúc này, vui lòng kiểm tra kết nối.",
          "warning"
        );
        return false;
      } finally {
        setVotingCandidateId(null);
      }
    },
    [
      sessionStatus,
      voteStatus,
      votingCandidateId,
      openSignInPrompt,
      showToast,
      mutateCandidates,
      mutateVoteStatus,
      fallbackData,
    ]
  );

  const candidates = candidatesData?.candidates ?? fallbackData.candidates;
  const totalVotes = candidatesData?.totalVotes ?? fallbackData.totalVotes;
  const maxDailyVotes = voteStatus?.maxDailyVotes ?? 3;
  const votesUsedToday = voteStatus?.votesUsedToday ?? 0;
  const remainingVotes =
    sessionStatus === "authenticated" || voteStatus?.authenticated
      ? (voteStatus?.remainingVotes ?? 3)
      : 3;
  const isAuthenticated =
    sessionStatus === "authenticated" || Boolean(voteStatus?.authenticated);
  const isDailyLimitReached = isAuthenticated && remainingVotes <= 0;
  const votedCandidateIdsToday = voteStatus?.votedCandidateIdsToday ?? [];
  const nextResetAt = voteStatus?.nextResetAt ?? null;

  return {
    candidates,
    totalVotes,
    sseConnected,
    liveFeed,
    toastMessage,
    dismissToast: () => setToastMessage(null),
    isAuthenticated,
    sessionUser: voteStatus?.user ?? (session?.user
      ? {
          id: session.user.id || "",
          email: session.user.email || "",
          name: session.user.name ?? null,
          avatarUrl: session.user.image ?? null,
        }
      : null),
    maxDailyVotes,
    votesUsedToday,
    remainingVotes,
    isDailyLimitReached,
    votedCandidateIdsToday,
    nextResetAt,
    votingCandidateId,
    castVote,
    isAuthModalOpen,
    authModalCandidate,
    openSignInPrompt,
    closeSignInPrompt,
    handleMidnightReset,
  };
}
